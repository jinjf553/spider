import base64
import os
import re
import shutil
import subprocess
import sys
import time
import traceback
import urllib.request
import winreg
from pathlib import Path
from threading import Thread
from time import sleep
from tkinter import messagebox
from typing import List

import chardet
import pyperclip
import win32api
import win32con
import win32gui

from main import (ALLUSERS_GIT_DIR, FASTRPA_DIR, RPA_PORT, RPA_SHELL_DIR,
                  TB_URL, chk_rpa_user_exists, chk_termsrvdll_version,
                  control_window, get_cmd_output, get_rpa_port)

# Thread(target=lambda: subprocess.run(r'mstsc "third_part/rdp.rdp" /w:1 /h:1 /admin'), daemon=True).start()
# # subprocess.run(rf'cmd.exe /c mstsc "C:\Users\jinjf\Desktop\Default4.rdp" /w:1 /h:1 /admin  ', stdout=subprocess.PIPE)
# print(1234)
# control_window("远程桌面连接", op="close")
# winreg.CreateKey(winreg.HKEY_LOCAL_MACHINE, r'SOFTWARE\Policies\Microsoft\Windows\OOBE')  # 为避免key不存在打开时报错，要先创建
# with winreg.OpenKey(winreg.HKEY_LOCAL_MACHINE, r'SOFTWARE\Policies\Microsoft\Windows\OOBE', 0, winreg.KEY_SET_VALUE) as key:
#     winreg.SetValueEx(key, 'DisablePrivacyExperience', 1, winreg.REG_DWORD, 1)
# chk_rpa_user_exists()
# subprocess.run(r'mstsc "third_part/rdp.rdp" /w:1 /h:1 /admin')
# Thread(target=lambda: subprocess.run(r'mstsc "third_part/rdp.rdp" /w:1 /h:1 /admin'), daemon=True).start()
# time.sleep(30)
print(RPA_PORT)
# win32api.SetFileAttributes(r'C:\Users\rpa4', win32con.FILE_ATTRIBUTE_HIDDEN)
# shutil.copyfile(r"D:\行云\rpa_shell\third_part\RPA.exe", r"C:\Users\rpa4\AppData\Roaming\Microsoft\Windows\Start Menu\Programs\Startup\RPA.exe")
# get_rpa_port('rpa1')
# hwnd = win32gui.FindWindow(None, 'rdp - 127.0.0.2 - 远程桌面连接')
# win32gui.ShowWindow(hwnd, win32con.SW_HIDE)
# print(win32gui.IsWindowVisible(hwnd))
# win32gui.ShowWindow(hwnd, win32con.SW_SHOWNORMAL)
# print(win32gui.IsWindowVisible(hwnd))
# print(win32gui.GetWindowRect(hwnd))
# print(dir(win32gui))
# print(Exception())
# cmd_stdout = subprocess.Popen("cmd.exe net user rpa1", stdout=subprocess.PIPE, shell=True).stdout.read()
# print(str(cmd_stdout.decode(chardet.detect(cmd_stdout)['encoding'] or 'utf8')))
# print(f'cmd.exe /c "{RPA_SHELL_DIR}/third_part/rdpwinst.bat" -i')
# cmd_stdout = get_cmd_output(f"net user rpa1")
# # cmd_stdout = try_run_subprocess(f'cmd.exe /c net user {uname}')
# print(bool(str(cmd_stdout.decode(chardet.detect(cmd_stdout)['encoding'] or 'utf8'))))
# cmd_stdout = get_cmd_output(f'net user rpa1 jinjf /add /expires:never')
# print(str(cmd_stdout.decode(chardet.detect(cmd_stdout)['encoding'] or 'utf8')))

# cmd_stdout = get_cmd_output(fr'"{RPA_SHELL_DIR}\third_part\cryptRDP5.exe" "jinjf"')
# rdp5pwd = cmd_stdout.decode(chardet.detect(cmd_stdout)['encoding'] or 'utf8')
# open(f'third_part/rdp.rdp', 'a+', encoding='utf-16').write(f'password 51:b:{rdp5pwd}')


def get_version():
    info = win32api.GetFileVersionInfo(r"D:\rpa\termsrv\termsrv.dll", os.sep)
    ms, ls = info['FileVersionMS'], info['FileVersionLS']
    version = '%d.%d.%d.%04d' % (win32api.HIWORD(ms), win32api.LOWORD(ms), win32api.HIWORD(ls), win32api.LOWORD(ls))
    print(version)
    if version not in Path(f"{RPA_SHELL_DIR}/third_part/rdpwrap.ini").read_text(encoding="utf-8"):
        dic = find_all_text()
        for key, value in dic.items():
            with open(f"{RPA_SHELL_DIR}/third_part/rdpwrap.ini", 'a+') as f:
                f.write(f"\n[{version}{key}]")
            for k, v in value.items():
                with open(f"{RPA_SHELL_DIR}/third_part/rdpwrap.ini", 'a+') as f:
                    f.write(f"\n{k}={v}")


def find_all_text():
    termsrv = r"D:\rpa\termsrv\termsrv_text.txt"
    all_text = open(termsrv, 'r', encoding='utf-8').read()
    # print(type(all_text), chardet.detect(all_text)['encoding'])
    dic = {'': {'LocalOnlyPatch.x64': '1',
                'LocalOnlyOffset.x64': '8FCB1',
                'LocalOnlyCode.x64': 'jmpshort',
                'SingleUserPatch.x64': '1',
                'SingleUserOffset.x64': '13852',
                'SingleUserCode.x64': 'Zero',
                'DefPolicyPatch.x64': '1',
                'DefPolicyOffset.x64': '17B85',
                'DefPolicyCode.x64': 'CDefPolicy_Query_eax_rcx',
                'SLInitHook.x64': '1',
                'SLInitOffset.x64': '1AE5C',
                'SLInitFunc.x64': 'New_CSLQuery_Initialize'},
           '-SLInit': {}
           }
    dic['']['SingleUserOffset.x64'] = re.findall('__fastcall CSessionArbitrationHelper::IsSingleSessionPerUserEnabled[\s\S]*?([0-9A-F]{5}) *? mov *? ebx', all_text)[0]
    dic['']['DefPolicyOffset.x64'] = re.findall('__fastcall CDefPolicy::Query[\s\S]*?([0-9A-F]{5}) *? cmp *? \[rcx\+63Ch\]', all_text)[0]
    dic['']['LocalOnlyOffset.x64'] = re.findall('PEAH@Z ; CSLQuery::IsLicenseTypeLocalOnly[\s\S]*?([0-9A-F]{5}) *? jz *? short', all_text)[0]
    dic['']['SLInitOffset.x64'] = re.findall('([0-9A-F]{5}) *? .*?int32 CSLQuery::Initialize', all_text)[0]
    dic['-SLInit']['bInitialized.x64'] = re.findall('([0-9A-F]{5}) *? .*?static int CSLQuery::bInitialized', all_text)[0]
    dic['-SLInit']['bFUSEnabled.x64'] = re.findall('([0-9A-F]{5}) *? .*?static int CSLQuery::bFUSEnabled', all_text)[0]
    dic['-SLInit']['lMaxUserSessions.x64'] = re.findall('([0-9A-F]{5}) *? .*?static long CSLQuery::lMaxUserSessions', all_text)[0]
    dic['-SLInit']['bServerSku.x64'] = re.findall('([0-9A-F]{5}) *? .*?static int CSLQuery::bServerSku', all_text)[0]
    dic['-SLInit']['bAppServerAllowed.x64'] = re.findall('([0-9A-F]{5}) *? .*?static int CSLQuery::bAppServerAllowed', all_text)[0]
    dic['-SLInit']['bRemoteConnAllowed.x64'] = re.findall('([0-9A-F]{5}) *? .*?static int CSLQuery::bRemoteConnAllowed', all_text)[0]
    dic['-SLInit']['bMultimonAllowed.x64'] = re.findall('([0-9A-F]{5}) *? .*?static int CSLQuery::bMultimonAllowed', all_text)[0]
    dic['-SLInit']['ulMaxDebugSessions.x64'] = re.findall('([0-9A-F]{5}) *? .*?static unsigned long CSLQuery::ulMaxDebugSessions', all_text)[0]
    return dic


if __name__ == "__main__":
    get_version()
    # find_all_text()
