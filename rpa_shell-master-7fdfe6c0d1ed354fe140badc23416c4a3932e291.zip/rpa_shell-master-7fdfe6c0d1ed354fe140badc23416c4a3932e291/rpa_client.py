"""虚拟环境：cd rpa_shell
            python -m venv env
            .\env\Scripts\Activate.ps1
   安装依赖：python -m pip install pyperclip pywin32==228 -i http://mirrors.aliyun.com/pypi/simple/ --trusted-host mirrors.aliyun.com
            python -m pip install wheel -i http://mirrors.aliyun.com/pypi/simple/ --trusted-host mirrors.aliyun.com
            python -m pip install pyinstaller -i http://mirrors.aliyun.com/pypi/simple/ --trusted-host mirrors.aliyun.com
   打包语句：pyinstaller ./rpa_client.py --clean --noupx -F -w -i ./cmder_blue.ico -n RPA
   -----------------------
   如果打包后程序启动错误，用以下命令重新打包，并在控制台执行打包后程序，查看异常原因
            pyinstaller ./main.py --clean  --noupx -F -w -i ./cmder_blue.ico -n RPA启动器_V20200328 --add-binary=./third_part;./third_part
    如果显示win32gui导入错误，尝试重新安装pyinstaller
"""
import base64
import os
import shutil
import subprocess
import time
import traceback
from pathlib import Path
from time import sleep

ROAMING_DIR = Path(str(os.environ.get('APPDATA'))).as_posix()
FASTRPA_DIR = Path(ROAMING_DIR).joinpath('fastrpa').as_posix()
ALLUSERS_GIT_DIR = Path(r"C:\Program Files\Git").as_posix()
RPA_TEMP_DIR = Path(f'd:/rpa/temp').as_posix()
VIRTUAL_ENV_DIR = Path(f'd:/rpa/venv').joinpath('exe').as_posix()
PYTHON_INSTALL_DIR = Path(r"C:\Program Files\python").as_posix()
TB_URL = b'aHR0cHM6Ly8xNTgwNTE5OTAwODpmYkt1ZjlwazlMYXhLUE1FdXZmTkZzdkpnaWU2eURLb3FRTUdG\ndnNSQGNvZGV1cC50ZWFtYml0aW9uLmNvbS9mYXN0cnBhL2Zhc3RycGEuZ2l0\n'


def get_cmd_output(cmd_line: str, cwd: str) -> str:
    for _ in range(10):
        try:
            p = subprocess.Popen(cmd_line, stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE, cwd=cwd, shell=True, start_new_session=True)
            if p.stdout is not None:
                out = p.stdout.read()
                return out
            return ''
        except Exception as e:
            err = e
    else:
        raise err


def git_fetch_fastrpa() -> bool:
    os.chdir(FASTRPA_DIR)
    subprocess.Popen(f'"{ALLUSERS_GIT_DIR}/bin/git.exe" reset --hard origin/prod').communicate()
    for _ in range(3):
        try:
            if 'up to date' in get_cmd_output(f'"{ALLUSERS_GIT_DIR}/bin/git.exe" pull origin prod -vf', FASTRPA_DIR).decode():
                return True
        except Exception:
            pass
            sleep(1)
    return False


def chk_rpa_update():
    if Path(FASTRPA_DIR).exists() is False:
        subprocess.Popen(f'"{ALLUSERS_GIT_DIR}/bin/git.exe" clone {base64.decodebytes(TB_URL).decode("utf-8")} -b prod --single-branch --depth 1 {FASTRPA_DIR}').communicate()
    is_update_flag = False
    try:
        if Path(FASTRPA_DIR).joinpath('.git/index.lock').exists() is True:  # 如果文件夹被锁定，则释放
            try:
                os.remove(Path(FASTRPA_DIR).joinpath('.git/index.lock').as_posix())
            except Exception:
                pass
        is_update_flag = git_fetch_fastrpa()
    except Exception:
        with open(f"{ROAMING_DIR}/RPASTATE", "w") as f:
            f.write(traceback.format_exc())
        return True
    if is_update_flag is False:
        with open(f"{ROAMING_DIR}/RPASTATE", "w") as f:
            f.write('RPA更新遇到问题，当前版本非最新，请检查网络连接。')
        return True


def activate_venv():
    os.chdir(FASTRPA_DIR)
    new_env = os.environ.copy()
    new_env['VIRTUAL_ENV'] = f'{VIRTUAL_ENV_DIR}'
    new_env['PYTHONHOME'] = f'{PYTHON_INSTALL_DIR}'
    new_env['PYTHONPATH'] = f';{VIRTUAL_ENV_DIR}'
    new_env['PYTHONPATH'] += f';{VIRTUAL_ENV_DIR}/lib/site-packages'
    new_env['PYTHONPATH'] += f';{VIRTUAL_ENV_DIR}/lib/site-packages/win32'
    new_env['PYTHONPATH'] += f';{VIRTUAL_ENV_DIR}/lib/site-packages/win32/lib'
    new_env['PYTHONPATH'] += f';{VIRTUAL_ENV_DIR}/lib/site-packages/pythonwin'
    new_env['PYTHONPATH'] += f';{PYTHON_INSTALL_DIR}'
    new_env['PYTHONPATH'] += f';{PYTHON_INSTALL_DIR}/lib'
    new_env['PYTHONPATH'] += f';{PYTHON_INSTALL_DIR}/dlls'
    new_env['QT_QPA_PLATFORM_PLUGIN_PATH'] = f'{VIRTUAL_ENV_DIR}/Lib/site-packages/PyQt5/Qt/plugins/platforms'
    return new_env


def launch_rpa():
    try:
        shutil.rmtree(RPA_TEMP_DIR)
    except Exception:
        pass
    for _ in range(60):
        if not chk_rpa_update():
            break
        time.sleep(1)
    else:
        return
    rpafile = f"{ROAMING_DIR}/RPAREADY"
    while True:
        if Path(rpafile).exists() and os.path.getmtime(rpafile) > time.time() - 120:
            subprocess.Popen(f'{VIRTUAL_ENV_DIR}/Scripts/python ./src/ssc_kit/hr/rpa_launcher/main_1.py', env=activate_venv(), shell=True, cwd=FASTRPA_DIR, start_new_session=True, stdout=None, stderr=None)
            os.remove(rpafile)
            break
        else:
            time.sleep(0.5)


if __name__ == "__main__":
    launch_rpa()
