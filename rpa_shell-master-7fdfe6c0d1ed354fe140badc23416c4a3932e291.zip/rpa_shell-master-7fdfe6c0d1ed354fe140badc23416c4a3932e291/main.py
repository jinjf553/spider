"""虚拟环境：cd rpa_shell
            python -m venv env
            .\env\Scripts\Activate.ps1
   安装依赖：python -m pip install pyperclip pywin32==228 -i http://mirrors.aliyun.com/pypi/simple/ --trusted-host mirrors.aliyun.com
            python -m pip install wheel -i http://mirrors.aliyun.com/pypi/simple/ --trusted-host mirrors.aliyun.com
            python -m pip install pyinstaller -i http://mirrors.aliyun.com/pypi/simple/ --trusted-host mirrors.aliyun.com
   打包语句：pyinstaller ./main.py --clean --noupx -F --uac-admin -w -i ./cmder_blue.ico -n RPA启动器_V20210401_4 --add-binary='./third_part;./third_part'
   -----------------------
   如果打包后程序启动错误，用以下命令重新打包，并在控制台执行打包后程序，查看异常原因
            pyinstaller ./main.py --clean  --noupx -F -w -i ./cmder_blue.ico -n RPA启动器_V20200328 --add-binary=./third_part;./third_part
    如果显示win32gui导入错误，尝试重新安装pyinstaller
"""
import base64
import os
import re
import shutil
import subprocess
import sys
import time
import traceback
import urllib.request
import winreg
from pathlib import Path
from threading import Thread
from time import sleep
from tkinter import messagebox
from typing import List

import chardet
import pyperclip
import win32api
import win32con
import win32gui

from ui import dialog, tree  # type: ignore

DRIVE = "d" if Path(f'd:/').exists() else 'c'
PYTHON_INSTALL_DIR = Path(r"C:\Program Files\python").as_posix()
RPA_PORT = 0
ALLUSERS_GIT_DIR = Path(r"C:\Program Files\Git").as_posix()
APPDATA_DIR = Path(str(os.environ.get('APPDATA'))).as_posix()
ROAMING_DIR = Path(str(os.environ.get('APPDATA'))).as_posix()
FASTRPA_DIR = Path(ROAMING_DIR).joinpath('fastrpa').as_posix()
SETUP_DIR = Path(f'{DRIVE}:/rpa/安装包').as_posix()
RPA_TEMP_DIR = Path(f'{DRIVE}:/rpa/temp').as_posix()
PIP_DIR = Path(f'{DRIVE}:/rpa/安装包/pip').as_posix()
PIP_CACHE_DIR = Path(f'{DRIVE}:/rpa/安装包/pip_cache').as_posix()
LOG_DIR = Path(f'{DRIVE}:/rpa/logs').as_posix()
VIRTUAL_ENV_DIR = Path(f'{DRIVE}:/rpa/venv').joinpath('exe').as_posix()  # Path(APPDATA_DIR).joinpath('venv/exe').as_posix()
PIP_URL = f'file:///{PIP_DIR}'
RPA_SHELL_DIR = getattr(sys, '_MEIPASS') if hasattr(sys, '_MEIPASS') is True else Path(__file__).parent.as_posix()  # pylint: disable=fixme, no-member  # 代码根目录

TB_URL = b'aHR0cHM6Ly8xNTgwNTE5OTAwODpmYkt1ZjlwazlMYXhLUE1FdXZmTkZzdkpnaWU2eURLb3FRTUdG\ndnNSQGNvZGV1cC50ZWFtYml0aW9uLmNvbS9mYXN0cnBhL2Zhc3RycGEuZ2l0\n'


def download_file(uri: str, local: str):
    urllib.request.urlretrieve(uri, local)


def get_cmd_output(cmd_line: str = '', cwd: str = RPA_SHELL_DIR) -> str:
    for _ in range(10):
        try:
            p = subprocess.Popen(cmd_line, stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE, cwd=cwd, shell=True, start_new_session=True)
            if p.stdout is not None:
                out = p.stdout.read()
                return out
            return ''
        except Exception as e:
            err = e
    else:
        raise err


def chk_volume_d_exists():
    tree.selection_set('chk_volume_d_exists')
    if Path(f'{DRIVE}:/').exists() is True:
        tree.set('chk_volume_d_exists', 'info', '存在')
        try:
            for path in [SETUP_DIR, PIP_DIR, PIP_CACHE_DIR, LOG_DIR]:
                Path(path).mkdir(parents=True, exist_ok=True)
        except Exception as e:
            messagebox.showerror(f'错误信息：{e}', traceback.format_exc() + '\n创建RPA运行目录失败，请检查D盘是否写保护')
            tree.insert('chk_volume_d_exists', 'end', 'create_rpa_dir', text='创建RPA运行目录', values=('创建RPA运行目录失败，请检查D盘是否写保护', '未通过'))
            tree.set('chk_volume_d_exists', 'result', '未通过')
            raise e
        tree.insert('chk_volume_d_exists', 'end', 'create_rpa_dir', text='创建RPA运行目录', values=('创建完毕', '通过'))
        tree.selection_set('create_rpa_dir')
        tree.set('chk_volume_d_exists', 'result', '通过')
    else:
        messagebox.showerror('错误信息', 'D盘不存在，请检查驱动器盘符是否正确！')
        raise FileNotFoundError('D盘不存在，请检查驱动器盘符是否正确！')


def chk_repeat_run():
    tree.selection_set('chk_repeat_run')
    tree.set('chk_repeat_run', 'info', '未重复执行')
    tree.set('chk_repeat_run', 'result', '通过')


def chk_ie_active_mode():
    tree.selection_set('chk_ie_active_mode')
    tree.set('chk_ie_active_mode', 'info', 'IE为主动模式')
    tree.set('chk_ie_active_mode', 'result', '通过')


def install_msedge():
    # 如果D盘有离线安装包，则用D盘的安装包，没有内嵌的网络安装包，下载后将安装包复制到D盘
    edge_installer = None

    for exe_file in Path(SETUP_DIR).rglob('MicrosoftEdge*.exe'):
        if exe_file.stat().st_size >= 64 * 1024 * 1024:  # 安装包大小大于64兆
            edge_installer = exe_file.as_posix()
            break
    if edge_installer is None:
        edge_installer = Path(RPA_SHELL_DIR).joinpath('third_part/MicrosoftEdgeSetup.exe').as_posix()
    subprocess.Popen(edge_installer).communicate()


def copy_msedge_offline_installer_to_setup_dir():
    edge_installer = None
    for exe_file in Path(SETUP_DIR).rglob('MicrosoftEdge*.exe'):
        if exe_file.stat().st_size >= 64 * 1024 * 1024:  # 安装包大小大于64兆
            edge_installer = exe_file.as_posix()
            break
    if edge_installer is None:
        for programfiles_dir in ('PROGRAMFILES', 'PROGRAMFILES(X86)'):
            for exe_file in Path(str(os.environ.get(programfiles_dir))).joinpath('Microsoft/EdgeUpdate/').rglob('MicrosoftEdge*.exe'):
                if exe_file.stat().st_size >= 64 * 1024 * 1024:  # 安装包大小大于64兆
                    shutil.copyfile(exe_file, Path(SETUP_DIR).joinpath('MicrosoftEdgeSetup.exe'))
                    return


def chk_msedge_installed():
    tree.selection_set('chk_msedge_installed')
    is_edge_installed = False
    if Path(str(os.environ.get('PROGRAMFILES(X86)'))).joinpath('Microsoft/Edge/Application/msedge.exe').exists() is True:
        is_edge_installed = True
    elif Path(str(os.environ.get('PROGRAMFILES'))).joinpath('Microsoft/Edge/Application/msedge.exe').exists() is False:
        is_edge_installed = True
    elif Path(ROAMING_DIR).parent.joinpath('Local/Microsoft/Edge/Application/msedge.exe').exists():
        is_edge_installed = True
    for path_dir in os.get_exec_path():
        edge_exe = Path(path_dir).joinpath('msedge.exe')
        if edge_exe.exists() is True:
            is_edge_installed = True
            break
    if is_edge_installed is False:
        tree.insert('chk_msedge_installed', 'end', 'install_msedge', text='安装Edge浏览器', values=('安装中，请稍等……'))
        tree.selection_set('install_msedge')
        install_msedge()
        tree.set('install_msedge', 'info', '安装完毕')
        tree.set('install_msedge', 'result', '通过')
    tree.set('chk_msedge_installed', 'info', '备份Edge浏览器离线安装包')
    copy_msedge_offline_installer_to_setup_dir()
    tree.set('chk_msedge_installed', 'info', 'Edge浏览器已安装')
    tree.set('chk_msedge_installed', 'result', '通过')


def is_webview2_installed() -> bool:
    reg_key = None
    try:
        # runtime
        reg_key = winreg.OpenKey(winreg.HKEY_LOCAL_MACHINE,
                                 r'SOFTWARE\WOW6432Node\Microsoft\EdgeUpdate\Clients\{F3017226-FE2A-4295-8BDF-00C3A9A7E4C5}')
        build, _ = winreg.QueryValueEx(reg_key, 'pv')
        build = int(build.replace('.', '')[:6])
        return build >= 860622  # Webview2 86.0.622.0
    except Exception:
        return False
    finally:
        if reg_key:
            winreg.CloseKey(reg_key)


def install_msedge_webview2():
    edge_webview2_installer = Path(RPA_SHELL_DIR).joinpath('thrid_part/MicrosoftEdgeWebview2Setup.exe').as_posix()
    subprocess.Popen(edge_webview2_installer).communicate()


def chk_msedge_webview2_installed():
    tree.selection_set('chk_msedge_webview2_installed')
    if is_webview2_installed() is False:
        tree.insert('chk_msedge_webview2_installed', 'end', 'install_msedge_webview2', text='安装Edge Webview2', values=('安装中，请稍等……'))
        tree.selection_set('install_msedge_webview2')
        install_msedge_webview2()
        tree.set('install_msedge_webview2', 'info', '安装完毕')
        tree.set('install_msedge_webview2', 'result', '通过')
    tree.set('chk_msedge_webview2_installed', 'info', 'Edge Webview2已安装')
    tree.set('chk_msedge_webview2_installed', 'result', '通过')


def is_dot_net_framework_above_462() -> bool:
    """检查.net framework版本是否高于4.6.2"""
    reg_key = None
    try:
        reg_key = winreg.OpenKey(winreg.HKEY_LOCAL_MACHINE, r'SOFTWARE\Microsoft\NET Framework Setup\NDP\v4\Full')
        version, _ = winreg.QueryValueEx(reg_key, 'Release')
        return version >= 394802   # .NET 4.6.2
    except Exception:
        return False
    finally:
        if reg_key:
            winreg.CloseKey(reg_key)


def install_dot_net_framework():
    dot_net_framework_installer = Path(RPA_SHELL_DIR).joinpath('thrid_part/ndp48-web.exe').as_posix()
    subprocess.Popen(dot_net_framework_installer).communicate()


def chk_dot_net_framework_above_462():
    tree.selection_set('chk_dot_net_framework_above_462')
    if is_dot_net_framework_above_462() is False:
        tree.insert('chk_dot_net_framework_above_462', 'end', 'install_dot_net_framework', text='安装.NET Framework', values=('安装中，请稍等……'))
        tree.selection_set('install_dot_net_framework')
        install_dot_net_framework()
        tree.set('install_dot_net_framework', 'info', '安装完毕')
        tree.set('install_dot_net_framework', 'result', '通过')
    tree.set('chk_dot_net_framework_above_462', 'info', '.NET Framework已安装')
    tree.set('chk_dot_net_framework_above_462', 'result', '通过')


def chk_python_383_installer_exists():
    tree.selection_set('chk_python_383_installer_exists')
    if Path(f'{SETUP_DIR}/python-3.8.3-amd64.exe').exists() is True and Path(f'{SETUP_DIR}/python-3.8.3-amd64.exe').stat().st_size != 27805800:
        tree.set('chk_python_383_installer_exists', 'info', f'{SETUP_DIR}/python-3.8.3-amd64.exe文件不完整，重新下载')
        os.remove(Path(f'{SETUP_DIR}/python-3.8.3-amd64.exe').as_posix())
    if Path(f'{SETUP_DIR}/python-3.8.3-amd64.exe').exists() is False:
        tree.set('chk_python_383_installer_exists', 'info', f'{SETUP_DIR}/python-3.8.3-amd64.exe不存在')
        tree.insert('chk_python_383_installer_exists', 'end', 'download_python_383_installer', text='下载Python3.8.3安装包', values=('下载中，请稍等……'))
        tree.selection_set('download_python_383_installer')
        try:
            download_file(r'http://npm.taobao.org/mirrors/python/3.8.3/python-3.8.3-amd64.exe', f'{SETUP_DIR}/python-3.8.3-amd64.exe')
        except Exception as e:
            messagebox.showerror(f'错误信息：{e}', traceback.format_exc() + '\n下载Python3.8.3安装包失败，请检查网络连接')
            tree.set('download_python_383_installer', 'info', '下载失败')
            tree.set('download_python_383_installer', 'result', '未通过')
            tree.set('chk_python_383_installer_exists', 'result', '未通过')
            raise e
        tree.set('download_python_383_installer', 'info', '下载成功')
        tree.set('download_python_383_installer', 'result', '通过')
    tree.set('chk_python_383_installer_exists', 'info', f'{SETUP_DIR}/python-3.8.3-amd64.exe存在')
    tree.set('chk_python_383_installer_exists', 'result', '通过')


def install_python():
    python_install_dir = PYTHON_INSTALL_DIR.replace('/', '\\')  # TargetDir 只支持 Windows 路径格式
    subprocess.Popen(f'{SETUP_DIR}/python-3.8.3-amd64.exe /passive TargetDir="{python_install_dir}" PrependPath=1 InstallAllUsers=1 Include_pip=1').communicate()


def uninstall_python():
    subprocess.Popen(f'{SETUP_DIR}/python-3.8.3-amd64.exe /uninstall /passive').communicate()


def chk_python_installed():
    tree.selection_set('chk_python_installed')
    if shutil.which('pythonw') is not None:
        if Path(f'{PYTHON_INSTALL_DIR}/python.exe').exists() is False:
            uninstall_python()
            install_python()
        tree.set('chk_python_installed', 'info', 'Python已安装')
    elif Path(f'{PYTHON_INSTALL_DIR}/python.exe').exists() is False:
        install_python()
    tree.set('chk_python_installed', 'result', '通过')


def chk_python_version_above_383():
    tree.selection_set('chk_python_version_above_383')
    tree.set('chk_python_version_above_383', 'info', 'Python已安装')
    tree.set('chk_python_version_above_383', 'result', '通过')


def chk_git_227_installer_exists():
    tree.selection_set('chk_git_227_installer_exists')
    if Path(f'{SETUP_DIR}/Git-2.27.0-64-bit.exe').exists() is True and Path(f'{SETUP_DIR}/Git-2.27.0-64-bit.exe').stat().st_size != 48066136:
        tree.set('chk_python_383_installer_exists', 'info', f'{SETUP_DIR}/Git-2.27.0-64-bit.exe文件不完整，重新下载')
        os.remove(Path(f'{SETUP_DIR}/Git-2.27.0-64-bit.exe').as_posix())
    if Path(f'{SETUP_DIR}/Git-2.27.0-64-bit.exe').exists() is False:
        tree.set('chk_git_227_installer_exists', 'info', f'{SETUP_DIR}/Git-2.27.0-64-bit.exe不存在')
        tree.insert('chk_git_227_installer_exists', 'end', 'download_git_227_installer', text='下载Git2.27.0安装包', values=('下载中，请稍等……'))
        tree.selection_set('download_git_227_installer')
        try:
            download_file(r'https://npm.taobao.org/mirrors/git-for-windows/v2.27.0.windows.1/Git-2.27.0-64-bit.exe', f'{SETUP_DIR}/Git-2.27.0-64-bit.exe')
        except Exception as e:
            messagebox.showerror(f'错误信息：{e}', traceback.format_exc() + '\n下载Python3.8.3安装包失败，请检查网络连接')
            tree.set('download_git_227_installer', 'info', '下载失败')
            tree.set('download_git_227_installer', 'result', '未通过')
            tree.set('chk_git_227_installer_exists', 'result', '未通过')
            raise e
        tree.set('download_git_227_installer', 'info', '下载成功')
        tree.set('download_git_227_installer', 'result', '通过')
    tree.set('chk_git_227_installer_exists', 'info', f'{SETUP_DIR}/Git-2.27.0-64-bit.exe存在')
    tree.set('chk_git_227_installer_exists', 'result', '通过')


def install_git():
    subprocess.Popen(f'{SETUP_DIR}/Git-2.27.0-64-bit.exe /silent /DIR="{ALLUSERS_GIT_DIR}" /ALLUSERS /COMPONENTS=').communicate()


def chk_git_installed():
    tree.selection_set('chk_git_installed')
    if Path(f'{ALLUSERS_GIT_DIR}/bin/git.exe').exists() is False:
        tree.insert('chk_git_installed', 'end', 'install_git', text='安装Git', values=('安装中，请稍等……'))
        tree.selection_set('install_git')
        install_git()
        tree.set('install_git', 'info', '安装完毕')
        tree.set('install_git', 'result', '通过')
    else:
        tree.set('chk_git_installed', 'info', 'Git已安装')
    tree.set('chk_git_installed', 'result', '通过')


def chk_termsrvdll_version():
    info = win32api.GetFileVersionInfo(r"C:\Windows\System32\termsrv.dll", os.sep)
    ms, ls = info['FileVersionMS'], info['FileVersionLS']
    version = '%d.%d.%d.%04d' % (win32api.HIWORD(ms), win32api.LOWORD(ms), win32api.HIWORD(ls), win32api.LOWORD(ls))
    if version not in Path(f"{RPA_SHELL_DIR}/third_part/rdpwrap.ini").read_text(encoding="utf-8"):
        messagebox.showerror("DLL错误", "RPA 安装配置失败，请联系开发工程师")
        raise Exception("RPA 安装配置失败，请联系开发工程师")
    machine_path = r"C:\Windows\System32\GroupPolicy\Machine"
    shutil.rmtree(machine_path, ignore_errors=True)
    os.makedirs(machine_path, exist_ok=True)
    shutil.copyfile(f'{RPA_SHELL_DIR}/third_part/comment.cmtx', f'{machine_path}/comment.cmtx')
    shutil.copyfile(f'{RPA_SHELL_DIR}/third_part/Registry.pol', f'{machine_path}/Registry.pol')
    # 设置新建用户初始化选项跳过，设置多用户远程桌面服务策略
    reg_path = r"Microsoft\Windows\CurrentVersion\Group Policy Objects\{3AB52391-4F8F-4436-9E49-86F4DD8ACC23}Machine\SOFTWARE\Policies\Microsoft\Windows NT\Terminal Services"
    winreg.CreateKey(winreg.HKEY_CURRENT_USER, reg_path)  # 为避免key不存在打开时报错，要先创建
    with winreg.OpenKey(winreg.HKEY_CURRENT_USER, reg_path, 0, winreg.KEY_SET_VALUE) as key:
        winreg.SetValueEx(key, 'fSingleSessionPerUser', 1, winreg.REG_DWORD, 0)
        winreg.SetValueEx(key, 'MaxInstanceCount', 1, winreg.REG_DWORD, 1)
        winreg.SetValueEx(key, 'Shadow', 1, winreg.REG_DWORD, 2)
    winreg.CreateKey(winreg.HKEY_LOCAL_MACHINE, r'SOFTWARE\Policies\Microsoft\Windows\OOBE')  # 为避免key不存在打开时报错，要先创建
    with winreg.OpenKey(winreg.HKEY_LOCAL_MACHINE, r'SOFTWARE\Policies\Microsoft\Windows\OOBE', 0, winreg.KEY_SET_VALUE) as key:
        winreg.SetValueEx(key, 'DisablePrivacyExperience', 1, winreg.REG_DWORD, 1)


def get_rpa_port(rpa_user):
    global RPA_PORT
    for _ in range(900):
        try:
            cmd_stdout = get_cmd_output(f'tasklist /FI "USERNAME eq {rpa_user}"')
            pids = re.findall("python.exe .*? (\d+) ", str(cmd_stdout.decode(chardet.detect(cmd_stdout)['encoding'] or 'utf8')))
            for pid in pids:
                cmd_stdout = get_cmd_output(f'cmd.exe /c netstat -aon | findstr "{pid}"')
                ports = re.findall(f"0.0.0.0:(\d+) .*? {pid}", str(cmd_stdout.decode(chardet.detect(cmd_stdout)['encoding'] or 'utf8')))
                if ports:
                    RPA_PORT = ports[0]
                    return
        except Exception:
            pass
        time.sleep(0.1)
    else:
        raise Exception("RPA启动失败")


def control_window(title, op="close"):
    for _ in range(3000):
        hwnd = win32gui.FindWindow(None, title)
        if hwnd:
            if op == "close":
                button = win32gui.FindWindowEx(hwnd, 0, None, "确定")  # 确定按钮Button
                win32gui.SendMessage(hwnd, win32con.WM_COMMAND, 0, button)
                # win32gui.PostMessage(hwnd, win32con.WM_CLOSE, 0, 0)
            else:
                if win32gui.IsWindowVisible(hwnd):
                    win32gui.ShowWindow(hwnd, win32con.SW_MAXIMIZE)
                    win32gui.ShowWindow(hwnd, win32con.SW_HIDE)
                # if not win32gui.IsWindowVisible(hwnd) and RPA_PORT:
                #     return
                    print(win32gui.GetWindowRect(hwnd))
                # win32gui.ShowWindow(hwnd, win32con.SW_SHOW)
        time.sleep(0.1)


def setup_and_startup_rpa(rpa_user):
    rpa_roaming = rf"C:\Users\{rpa_user}\AppData\Roaming"
    while True:
        if Path(rpa_roaming).exists():
            win32api.SetFileAttributes(rf'C:\Users\{rpa_user}', win32con.FILE_ATTRIBUTE_HIDDEN)
            startup_path = rf"{rpa_roaming}\Microsoft\Windows\Start Menu\Programs\Startup"
            os.makedirs(startup_path, exist_ok=True)
            shutil.copyfile(f'{RPA_SHELL_DIR}/third_part/RPA.exe', f'{startup_path}/RPA.exe')
            os.makedirs(f'{rpa_roaming}/SAP/Common', exist_ok=True)
            shutil.copyfile(f'{RPA_SHELL_DIR}/third_part/saplogon.ini', f'{rpa_roaming}/SAP/Common/saplogon.ini')
            shutil.copyfile(f'{RPA_SHELL_DIR}/third_part/SapLogonTree.xml', f'{rpa_roaming}/SAP/Common/SapLogonTree.xml')
            return
        time.sleep(0.1)


def start_rpa_user(rpa_user):
    on_users = get_cmd_output(f'query user')
    user_ids = re.findall(f'{rpa_user}.*? (\d+) ', str(on_users.decode(chardet.detect(on_users)['encoding'] or 'utf8')))
    for user_id in user_ids:
        get_cmd_output(f"logoff {user_id}")
        for _ in range(20):
            cmd_stdout = get_cmd_output(f'tasklist /FI "USERNAME eq {rpa_user}"')
            process_str = str(cmd_stdout.decode(chardet.detect(cmd_stdout)['encoding'] or 'utf8'))
            if "No tasks are running" in process_str or "没有运行的任务" in process_str:
                break
            time.sleep(0.5)
        time.sleep(0.5)
    # Thread(target=get_cmd_output, args=(r'mstsc "third_part/rdp.rdp" /w:1920 /h:1080 /admin', ), daemon=True).start()
    Thread(target=get_cmd_output, args=(rf'mstsc "{RPA_SHELL_DIR}/third_part/rdp.rdp" /w:1920 /h:1080 /admin', ), daemon=True).start()
    Thread(target=control_window, args=("rdp - 127.0.0.2 - 远程桌面连接", "hide"), daemon=True).start()
    Thread(target=get_rpa_port, args=(rpa_user, ), daemon=True).start()


def quit_360():
    while True:
        try:
            hwnd_list = {}
            win32gui.EnumWindows(lambda _hwnd, param: param.update({_hwnd: win32gui.GetWindowText(_hwnd)}), hwnd_list)
            for hwnd, all_title in hwnd_list.items():
                if "360天擎" in all_title or "Q360NetmonWnd" in all_title:
                    win32gui.PostMessage(hwnd, win32con.WM_QUIT, 0, 0)
        except Exception:
            pass
        time.sleep(1)


def try_run_subprocess(cmd):
    error = ""
    for _ in range(10):
        try:
            cmd_stdout = subprocess.Popen(cmd, stdout=subprocess.PIPE, stdin=subprocess.PIPE).communicate()
            return cmd_stdout[0]
        except Exception as e:
            error = e
    else:
        raise error


def chk_rpa_is_start(rpa_user):
    cmd_stdout = get_cmd_output(f'tasklist /FI "USERNAME eq {rpa_user}"')
    pids = re.findall("python.exe .*? (\d+) ", str(cmd_stdout.decode(chardet.detect(cmd_stdout)['encoding'] or 'utf8')))
    for pid in pids:
        cmd_stdout = get_cmd_output(f'cmd.exe /c netstat -aon | findstr "{pid}"')
        ports = re.findall(f"0.0.0.0:(\d+) .*? {pid}", str(cmd_stdout.decode(chardet.detect(cmd_stdout)['encoding'] or 'utf8')))
        if ports:
            Thread(target=get_cmd_output, args=(rf'mstsc "{RPA_SHELL_DIR}/third_part/rdp.rdp" /w:1920 /h:1080 /admin', ), daemon=True).start()
            Thread(target=control_window, args=("rdp - 127.0.0.2 - 远程桌面连接", "hide"), daemon=True).start()
            Thread(target=control_window, args=("远程桌面连接", "close"), daemon=True).start()
            return ports[0]
    return 0


def chk_rpa_user_exists():
    tree.selection_set('chk_rpa_user_exists')
    global RPA_PORT
    uname, passwd = "rpa1", "jinjf"
    RPA_PORT = chk_rpa_is_start(uname)
    if RPA_PORT:
        tree.set('chk_rpa_user_exists', 'info', '存在')
        tree.set('chk_rpa_user_exists', 'result', '通过')
        return
    Thread(target=setup_and_startup_rpa, args=(uname, ), daemon=True).start()
    Thread(target=control_window, args=("远程桌面连接", "close"), daemon=True).start()
    cmd_stdout = get_cmd_output(f"net user {uname}")
    # cmd_stdout = try_run_subprocess(f'cmd.exe /c net user {uname}')
    if bool(str(cmd_stdout.decode(chardet.detect(cmd_stdout)['encoding'] or 'utf8'))) is False:
        get_cmd_output(f'net user {uname} {passwd} /add /expires:never')
    get_cmd_output(f'net localgroup Administrator {uname} /add')
    get_cmd_output(f'net localgroup "Remote Desktop Users" {uname} /add')
    get_cmd_output(f'wmic UserAccount where "Name=\'{uname}\'" set PasswordExpires=False')
    cmd_stdout = get_cmd_output(fr'"{RPA_SHELL_DIR}\third_part\cryptRDP5.exe" "{passwd}"')
    rdp5pwd = cmd_stdout.decode(chardet.detect(cmd_stdout)['encoding'] or 'utf8')
    open(f'{RPA_SHELL_DIR}/third_part/rdp.rdp', 'a+', encoding='utf-16').write(f'password 51:b:{rdp5pwd}')

    for _ in range(10):
        cmd_stdout = get_cmd_output(f'powershell "{RPA_SHELL_DIR}/third_part/rdpwinst.exe" -i')
        if Path(rf"C:\Program Files\RDP Wrapper\rdpwrap.dll").exists():
            break
    else:
        raise Exception(f'"{RPA_SHELL_DIR}/third_part/rdpwinst.exe" -i' + str(cmd_stdout.decode(chardet.detect(cmd_stdout)['encoding'] or 'utf8')))
    try:
        shutil.copyfile(f"{RPA_SHELL_DIR}/third_part/rdpwrap.ini", rf"C:\Program Files\RDP Wrapper\rdpwrap.ini")
    except Exception:
        messagebox.showerror("权限错误", "需要管理员权限运行")
        raise Exception("权限错误")
    chk_termsrvdll_version()
    start_rpa_user(uname)
    tree.set('chk_rpa_user_exists', 'info', '存在')
    tree.set('chk_rpa_user_exists', 'result', '通过')


def create_python_venv():
    os.chdir(FASTRPA_DIR)
    subprocess.Popen(f'"{PYTHON_INSTALL_DIR}/python.exe" -m venv {VIRTUAL_ENV_DIR}').communicate()


def chk_venv_exists():
    tree.selection_set('chk_venv_exists')
    if Path(VIRTUAL_ENV_DIR).exists() is False:
        tree.set('chk_venv_exists', 'info', '正在创建虚拟环境……')
        create_python_venv()
    is_venv_broken = False
    if Path(VIRTUAL_ENV_DIR).joinpath('Scripts/python.exe').exists() is False:
        is_venv_broken = True
    if Path(VIRTUAL_ENV_DIR).joinpath('pyvenv.cfg').exists() is False:
        is_venv_broken = True
    elif is_venv_broken is False:
        try:
            pyvenv_cfg = Path(VIRTUAL_ENV_DIR).joinpath('pyvenv.cfg').read_text(encoding='utf-8')
            match = re.findall('(?:home\s*=\s*)(.*)', pyvenv_cfg)  # ex:['C:\\Users\\username\\AppData\\Local\\Programs\\Python\\Python38']
            if Path(f"{match[0]}/python.exe").exists() is False:
                pyvenv_cfg = pyvenv_cfg.replace(match[0], PYTHON_INSTALL_DIR)
                Path(VIRTUAL_ENV_DIR).joinpath('pyvenv.cfg').write_text(pyvenv_cfg, encoding='utf-8')  # 系统重装用户目录改变，需更新python路径
        except Exception:
            is_venv_broken = True
    if is_venv_broken is True:
        try:
            messagebox.showerror('RPA运行环境损坏', '请手动删除文件夹d:/rpa/venv/exe，并重新打开启动器')
            tree.set('chk_venv_exists', 'info', '虚拟环境损坏，请手动删除并再启动程序')
            tree.set('chk_venv_exists', 'result', '未通过')
        except Exception:
            pass
    else:
        if Path(VIRTUAL_ENV_DIR).joinpath('Scripts/python.exe').exists():
            tree.set('chk_venv_exists', 'info', '虚拟环境已创建')
            tree.set('chk_venv_exists', 'result', '通过')
        else:
            tree.set('chk_venv_exists', 'info', '虚拟环境创建失败')
            tree.set('chk_venv_exists', 'result', '未通过')


def chk_windows_firewall():
    tree.selection_set('chk_windows_firewall')
    # 有可能无法执行，需要打开Powershell开关
    try:
        os.system('powershell -command "netsh advfirewall firewall show rule name="python.exe"" > d:/rpa/firewall.txt')
    except Exception:
        messagebox.showerror(f'错误信息：系统安全设置禁止执行powershell命令', '\n请以管理员身份打开PowerShell，并执行以下命令（已复制到剪切板）：' +
                             '\nset-ExecutionPolicy RemoteSigned' +
                             '\nSet-ExecutionPolicy -ExecutionPolicy RemoteSigned')
        pyperclip.copy('set-ExecutionPolicy RemoteSigned' +
                       '\nSet-ExecutionPolicy -ExecutionPolicy RemoteSigned')
        return
    powershell_rule = Path(f'{DRIVE}:/rpa/firewall.txt').read_text(encoding='gb2312')
    if '没有与指定标准相匹配的规则' in powershell_rule:
        pass
    elif '阻止' in powershell_rule:
        messagebox.showerror(f'错误信息：Windows防火墙屏蔽Python，RPA无法访网络', '\n请以管理员身份打开PowerShell，并执行以下命令（已复制到剪切板）：' +
                             '\nnetsh advfirewall firewall set rule name="python.exe" new action=allow' +
                             '\n执行后请关闭RPA启动器，并重新打开，验证修改是否生效')
        tree.set('chk_windows_firewall', 'info', '入站规则屏蔽Python，RPA无法访问网络')
        tree.set('chk_windows_firewall', 'result', '未通过')
        pyperclip.copy('netsh advfirewall firewall set rule name="python.exe" new action=allow')
        raise Exception('Windows防火墙屏蔽Python，RPA无法访网络')
    tree.set('chk_windows_firewall', 'info', '入站规则未屏蔽Python')
    tree.set('chk_windows_firewall', 'result', '通过')


def clone_rpa_repo():
    subprocess.Popen(f'"{ALLUSERS_GIT_DIR}/bin/git.exe" clone {base64.decodebytes(TB_URL).decode("utf-8")} -b prod --single-branch --depth 1 {FASTRPA_DIR}').communicate()


def git_fetch_fastrpa() -> bool:
    os.chdir(FASTRPA_DIR)
    subprocess.Popen(f'"{ALLUSERS_GIT_DIR}/bin/git.exe" reset --hard origin/prod').communicate()
    for _ in range(3):
        try:
            if 'up to date' in get_cmd_output(f'"{ALLUSERS_GIT_DIR}/bin/git.exe" pull origin prod -vf', FASTRPA_DIR).decode():
                return True
        except Exception:
            pass
            sleep(1)
    return False


def chk_rpa_update():
    tree.selection_set('chk_rpa_update')
    if Path(FASTRPA_DIR).exists() is False:
        tree.set('chk_rpa_update', 'info', '未检测到RPA代码')
        tree.insert('chk_rpa_update', 'end', 'clone_fastrpa', text='正在下载RPA代码', values=('安装中，请稍等……'))
        clone_rpa_repo()
        tree.set('clone_fastrpa', 'info', '下载完毕')
        tree.set('clone_fastrpa', 'result', '通过')
    tree.set('chk_rpa_update', 'info', 'RPA代码更新中……')
    is_update_flag = False
    try:
        if Path(FASTRPA_DIR).joinpath('.git/index.lock').exists() is True:  # 如果文件夹被锁定，则释放
            try:
                os.remove(Path(FASTRPA_DIR).joinpath('.git/index.lock').as_posix())
            except Exception:
                pass
        is_update_flag = git_fetch_fastrpa()
    except Exception as e:
        messagebox.showerror(f'错误信息：{e}', traceback.format_exc())
    if is_update_flag is True:
        tree.set('chk_rpa_update', 'info', 'RPA已更新到最新')
        tree.set('chk_rpa_update', 'result', '通过')
    else:
        messagebox.showerror(f'错误信息', 'RPA更新遇到问题，当前版本非最新，请检查网络连接。')
        tree.set('chk_rpa_update', 'info', 'RPA更新失败')
        tree.set('chk_rpa_update', 'result', '未通过')


def is_deps_match():
    tree.set('chk_deps_installed', 'info', '检测虚拟环境已安装包')
    pip_installed_list: List[str] = []  # 虚拟环境PIP安装哪些包 [package-name: package-version]
    pip_list_str = get_cmd_output(f'{VIRTUAL_ENV_DIR}/Scripts/python.exe -m pip list --disable-pip-version-check', VIRTUAL_ENV_DIR).decode()
    for line in pip_list_str.split('\n'):
        match = re.match('([\]\[\w-]+)\s*([0-9.]+)\s*', line)
        if match is not None:
            package_name = match.group(1).lower().replace('-', '_')
            package_version = match.group(2)
            pip_installed_list.append(package_name + '==' + package_version)
    tree.set('chk_deps_installed', 'info', '检测requirements.txt包名称')
    requirements_txt = Path(FASTRPA_DIR).joinpath('requirements.txt').as_posix()
    requirements_txt_str = Path(requirements_txt).read_text(encoding='utf-8')
    requirements_list: List[str] = []  # requirements.txt中的包 [package-name==package-version]
    for line in requirements_txt_str.split('\n'):
        match = re.match('([\w-]+)[\]\[\w-]*\s*==\s*([0-9.]+)', line)
        if match is not None:
            package_name = match.group(1).lower().replace('-', '_')
            package_version = match.group(2)
            requirements_list.append(package_name + '==' + package_version)
    pip_download_list: List[str] = []  # 虚拟环境PIP安装哪些包 [package-name: package-version]
    tree.set('chk_deps_installed', 'info', '检测本地pip安装包完整性')
    for file in Path(PIP_DIR).rglob('*'):
        if file.is_dir() is False:
            match = re.match('([\]\[\w-]+)-([0-9.]+)', file.name)
            if match is not None:
                package_name = match.group(1).lower().replace('-', '_')
                package_version = match.group(2).strip('.')
                pip_download_list.append(package_name + '==' + package_version)
    # requirements.txt中的包是否都在d:/rpa/安装包/pip中下载
    is_package_downloaded = all([package in pip_download_list for package in requirements_list]) is True
    # requirements.txt中的包是否都在虚拟环境中已安装且版本匹配
    is_package_installed = all([package in pip_installed_list for package in requirements_list]) is True
    return is_package_downloaded, is_package_installed


def download_pip_packages():
    os.chdir(FASTRPA_DIR)
    subprocess.Popen(f'{VIRTUAL_ENV_DIR}/Scripts/python -m pip download -i http://mirrors.aliyun.com/pypi/simple/' +
                     f' --disable-pip-version-check --cache-dir {SETUP_DIR}/pip_cache' +
                     f' --trusted-host mirrors.aliyun.com -r {FASTRPA_DIR}/requirements.txt -d {SETUP_DIR}/pip').communicate()


def install_pip_packages():
    os.chdir(FASTRPA_DIR)
    subprocess.Popen(f'{VIRTUAL_ENV_DIR}/Scripts/python -m pip install -r {FASTRPA_DIR}/requirements.txt --no-index --find-links {PIP_URL}').communicate()


def chk_deps_installed():
    tree.selection_set('chk_deps_installed')
    is_package_downloaded, is_package_installed = is_deps_match()
    if is_package_downloaded is False:
        tree.insert('chk_deps_installed', 'end', 'download_deps', text='检测到依赖更新', values=('正在下载最新模块，请稍等……'))
        tree.selection_set('download_deps')
        download_pip_packages()
        tree.set('download_deps', 'info', '模块下载完毕')
        tree.set('download_deps', 'result', '通过')
    if is_package_installed is False:
        tree.insert('chk_deps_installed', 'end', 'install_deps', text='安装最新依赖', values=('正在安装最新依赖，请稍等……'))
        tree.selection_set('install_deps')
        install_pip_packages()
        tree.set('install_deps', 'info', '依赖安装完毕')
        tree.set('install_deps', 'result', '通过')
    if Path(r'C:\Users\rpa1\AppData\Roaming').exists():
        open(r'C:\Users\rpa1\AppData\Roaming\RPAREADY', 'w').write("RPA准备就绪")
    tree.set('chk_deps_installed', 'info', '依赖模块已安装')
    tree.set('chk_deps_installed', 'result', '通过')


def before_check():
    chk_volume_d_exists()  # D盘是否存在
    # is_repeat_run()  # 重复执行
    chk_rpa_user_exists()  # rpa_user是否存在
    chk_ie_active_mode()  # IE主动模式
    dialog.attributes('-topmost', True)  # 窗口置顶（恢复置顶）
    dialog.attributes('-topmost', False)  # 窗口置顶（取消置顶，避免遮挡安装过程）
    chk_msedge_installed()  # 安装Edge浏览器
    chk_msedge_webview2_installed()  # 安装Edge Webview2
    chk_dot_net_framework_above_462()  # 检查.net framework版本是否高于4.6.2
    chk_git_227_installer_exists()  # Git2.27.0安装包
    chk_git_installed()  # Git是否安装
    chk_python_383_installer_exists()  # Python3.8.3安装包
    chk_python_installed()  # Python是否安装
    chk_python_version_above_383()  # Python是否为3.8.3版本
    chk_rpa_update()  # RPA是否为最新版本
    chk_venv_exists()  # 虚拟环境是否创建
    chk_windows_firewall()  # Windows防火墙策略入站规则是否屏蔽Python
    chk_deps_installed()  # 依赖模块是否完整
    dialog.attributes('-topmost', True)  # 窗口置顶（恢复置顶）
    tree.set('before_check', 'result', '通过')


def activate_venv():
    os.chdir(FASTRPA_DIR)
    new_env = os.environ.copy()
    new_env['VIRTUAL_ENV'] = f'{VIRTUAL_ENV_DIR}'
    new_env['PYTHONHOME'] = f'{PYTHON_INSTALL_DIR}'
    new_env['PYTHONPATH'] = f';{VIRTUAL_ENV_DIR}'
    new_env['PYTHONPATH'] += f';{VIRTUAL_ENV_DIR}/lib/site-packages'
    new_env['PYTHONPATH'] += f';{VIRTUAL_ENV_DIR}/lib/site-packages/win32'
    new_env['PYTHONPATH'] += f';{VIRTUAL_ENV_DIR}/lib/site-packages/win32/lib'
    new_env['PYTHONPATH'] += f';{VIRTUAL_ENV_DIR}/lib/site-packages/pythonwin'
    new_env['PYTHONPATH'] += f';{PYTHON_INSTALL_DIR}'
    new_env['PYTHONPATH'] += f';{PYTHON_INSTALL_DIR}/lib'
    new_env['PYTHONPATH'] += f';{PYTHON_INSTALL_DIR}/dlls'
    new_env['QT_QPA_PLATFORM_PLUGIN_PATH'] = f'{VIRTUAL_ENV_DIR}/Lib/site-packages/PyQt5/Qt/plugins/platforms'
    return new_env


def launch_rpa():
    tree.selection_set('rpa_launcher')
    tree.insert('rpa_launcher', 'end', 'rap_window', text='启动RPA窗口', values=('', ''))
    tree.selection_set('rap_window')
    tree.set('rap_window', 'info', '启动中……')
    try:
        shutil.rmtree(RPA_TEMP_DIR)
    except Exception:
        pass
    global RPA_PORT
    _ = [_ for _ in range(600) if (RPA_PORT if RPA_PORT else time.sleep(0.2))]
    if not RPA_PORT:
        tree.set('rap_window', 'info', '启动失败')
        tree.set('rap_window', 'result', '未通过')
        messagebox.showerror("失败", "RPA 启动失败")
        raise Exception("RPA 启动失败")
    _p = subprocess.Popen(f'{VIRTUAL_ENV_DIR}/Scripts/python ./src/ssc_kit/hr/rpa_launcher/main_1.py {RPA_PORT}', env=activate_venv(), shell=True, cwd=FASTRPA_DIR, start_new_session=True, stdout=None, stderr=None)
    # _p = subprocess.Popen(f'{VIRTUAL_ENV_DIR}/Scripts/python ./src/ssc_kit/hr/rpa_launcher_xinchou/main.py', env=activate_venv(), shell=True, cwd=FASTRPA_DIR, start_new_session=True, stdout=None, stderr=None)
    flag = False
    err_msg = ''
    for _ in range(60):
        if _p.poll() is not None:  # 程序已终止
            break
        if win32gui.FindWindow(None, '人事RPA平台') != 0:
            flag = True
            break
        else:
            sleep(1)
    if flag is True:
        tree.set('rap_window', 'info', '已启动')
        tree.set('rap_window', 'result', '通过')
        dialog.quit()
    else:
        tree.set('rap_window', 'info', '启动失败')
        tree.set('rap_window', 'result', '未通过')
        if err_msg == '':
            raise Exception(f'RPA未启动')
        else:
            raise Exception(f'RPA未启动，{err_msg}')


def chk_rpa_isnomal():
    while True:
        if Path(r'C:\Users\rpa1\AppData\Roaming\RPASTATE').exists():
            rpa_info = open(r'C:\Users\rpa1\AppData\Roaming\RPASTATE', 'r').read()
            messagebox.showerror(f"RPA异常", rpa_info)
            sys.exit()
        else:
            time.sleep(0.3)


def main():
    try:
        if Path(r'C:\Users\rpa1\AppData\Roaming\RPASTATE').exists():
            try: os.remove(r'C:\Users\rpa1\AppData\Roaming\RPASTATE')
            except Exception: pass
        Thread(target=quit_360, daemon=True).start()
        Thread(target=chk_rpa_isnomal, daemon=True).start()
        before_check()
    except Exception as e:
        tree.set('before_check', 'result', '未通过')
        messagebox.showerror(f'错误信息：{e}', traceback.format_exc())
        return
    launch_rpa()


def write_rpa_shell_exe_path_to_reg():
    winreg.CreateKey(winreg.HKEY_CURRENT_USER, r'SOFTWARE\FASTRPA\RPA_SHELL')  # 为避免key不存在打开时报错，要先创建
    with winreg.OpenKey(winreg.HKEY_CURRENT_USER, r'SOFTWARE\FASTRPA\RPA_SHELL', 0, winreg.KEY_SET_VALUE) as key:
        if hasattr(sys, '_MEIPASS') is True:
            winreg.SetValueEx(key, 'RPA_SHELL_PATH', 1, winreg.REG_SZ, sys.executable)
            winreg.SetValueEx(key, 'RPA_SHELL_VERSION', 1, winreg.REG_SZ, '2020-12-10 21:00:00')
    winreg.CreateKey(winreg.HKEY_CURRENT_USER, r'Software\Microsoft\Terminal Server Client\LocalDevices')  # 为避免key不存在打开时报错，要先创建
    with winreg.OpenKey(winreg.HKEY_CURRENT_USER, r'Software\Microsoft\Terminal Server Client\LocalDevices', 0, winreg.KEY_SET_VALUE) as key:
        winreg.SetValueEx(key, '127.0.0.2', 1, winreg.REG_DWORD, 8)


if __name__ == '__main__':
    t = Thread(target=main)
    t.setDaemon(True)
    t.start()
    write_rpa_shell_exe_path_to_reg()
    dialog.mainloop()
