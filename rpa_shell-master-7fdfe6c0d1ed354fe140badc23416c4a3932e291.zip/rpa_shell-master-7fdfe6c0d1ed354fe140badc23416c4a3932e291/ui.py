import tkinter as tk
from tkinter import *
from tkinter import messagebox
from tkinter.ttk import Treeview

dialog = Tk()
dialog.title('RPA启动（V20210315）')  # 窗口标题
dialog.resizable(0, 0)  # 禁用最大化按钮
dialog.attributes('-topmost', True)  # 窗口置顶
winWidth = 600  # 窗口宽度
winHeight = 500  # 窗口高度
# dialog.attributes('-alpha', 0.9)  # 透明度
# 获取屏幕分辨率
screenWidth = dialog.winfo_screenwidth()  # 屏幕宽度
screenHeight = dialog.winfo_screenheight()  # 屏幕高度
x = int((screenWidth - winWidth) / 2)
y = int((screenHeight - winHeight) / 2)
dialog.geometry('%sx%s+%s+%s' % (winWidth, winHeight, x, y))  # 窗口居中
# dialog.iconbitmap('./RPA_LAUNCHER/icon-windowed.ico')

# TreeView
tree = Treeview(dialog, show='tree headings', columns=('info', 'result'))
tree.pack(expand=True, fill=tk.BOTH)
# 标题行
tree.heading('#0', text='内容项')
tree.column("#0", minwidth=10, width=190, stretch=NO)
tree.heading('info', text='执行信息')

tree.heading('result', text='执行结果')
tree.column("result", minwidth=10, width=60, stretch=NO, anchor='center')

# before_check
tree.insert('', 'end', 'before_check', text='事前检查', values=(), open=True)
tree.insert('before_check', 'end', 'chk_volume_d_exists', text='D盘是否存在', values=('', ''), open=True)
tree.insert('before_check', 'end', 'chk_rpa_user_exists', text='RPA用户是否存在', values=('', ''), open=True)
# tree.insert('before_check', 'end', 'chk_repeat_run', text='重复执行', values=('', ''), open=True)
tree.insert('before_check', 'end', 'chk_ie_active_mode', text='IE主动模式', values=('', ''), open=True)
tree.insert('before_check', 'end', 'chk_msedge_installed', text='Edge 浏览器', values=('', ''), open=True)
tree.insert('before_check', 'end', 'chk_msedge_webview2_installed', text='Edge Webview2', values=('', ''), open=True)
tree.insert('before_check', 'end', 'chk_dot_net_framework_above_462', text='.NET Framework 4.6.2', values=('', ''), open=True)
tree.insert('before_check', 'end', 'chk_git_227_installer_exists', text='Git2.27.0本地安装程序', values=('', ''), open=True)
tree.insert('before_check', 'end', 'chk_git_installed', text='Git是否安装', values=('', ''), open=True)
tree.insert('before_check', 'end', 'chk_python_383_installer_exists', text='Python3.8.3本地安装程序', values=('', ''), open=True)
tree.insert('before_check', 'end', 'chk_python_installed', text='Python是否安装', values=('', ''), open=True)
tree.insert('before_check', 'end', 'chk_python_version_above_383', text='Python是否为3.8.3版本', values=('', ''), open=True)
tree.insert('before_check', 'end', 'chk_rpa_update', text='RPA是否为最新版本', values=('', ''), open=True)
tree.insert('before_check', 'end', 'chk_venv_exists', text='虚拟环境是否创建', values=('', ''), open=True)
tree.insert('before_check', 'end', 'chk_windows_firewall', text='Windows防火墙策略', values=('', ''), open=True)
tree.insert('before_check', 'end', 'chk_deps_installed', text='依赖模块是否完整', values=('', ''), open=True)

# CHECKER2
tree.insert('', 'end', 'rpa_launcher', text='启动项', values=(), open=True)
# CHECKER3
# tree.insert('', 'end', 'after_check', text='事后清理', values=(), open=True)  # 时候
# tree.insert('after_check', 'end', , text='执行清理工作', values=())
# tree.insert('after_check', 'end', None, text='关闭SAP进程', values=())
